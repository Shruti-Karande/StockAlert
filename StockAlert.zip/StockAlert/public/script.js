// LOGIN
async function login(){
  const res = await fetch('/login',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({
      username: document.getElementById("username").value,
      password: document.getElementById("password").value
    })
  });

  const data = await res.json();

  if(data.token){
    localStorage.setItem("token", data.token);
    window.location = "dashboard.html"; // ✅ redirect
  }else{
    document.getElementById("error").innerText = "Login failed";
  }
}

// NAVIGATION
function goManage(){
  window.location = "manage.html";
}

function goDashboard(){
  window.location = "dashboard.html";
}

// LOGOUT
function logout(){
  localStorage.removeItem("token");
  window.location = "login.html";
}

// DASHBOARD LOAD
async function loadDashboard(){
  const res = await fetch('/products',{
    headers:{ 'Authorization': localStorage.getItem("token") }
  });

  const data = await res.json();

  const tbody = document.getElementById("tbody");
  tbody.innerHTML = "";

  data.forEach(p=>{
    let row = document.createElement("tr");

    if(p.quantity < 5){
      row.classList.add("low");
    }

    row.innerHTML = `
      <td>${p.name}</td>
      <td>${p.quantity}</td>
      <td>${p.price}</td>
    `;

    tbody.appendChild(row);
  });
}

// MANAGE LOAD
async function loadManage(){
  const res = await fetch('/products',{
    headers:{ 'Authorization': localStorage.getItem("token") }
  });

  const data = await res.json();

  const tbody = document.getElementById("tbody");
  tbody.innerHTML = "";

  data.forEach(p=>{
    let row = document.createElement("tr");

    row.innerHTML = `
      <td>${p.name}</td>
      <td>${p.quantity}</td>
      <td>${p.price}</td>
      <td>
        <button onclick="edit('${p._id}','${p.name}',${p.quantity},${p.price})">Edit</button>
        <button onclick="del('${p._id}')">Delete</button>
      </td>
    `;

    tbody.appendChild(row);
  });
}

// ADD PRODUCT (FIXED)
async function addProduct(){
  const name = document.getElementById("name").value;
  const quantity = document.getElementById("qty").value;
  const price = document.getElementById("price").value;

  await fetch('/add',{
    method:'POST',
    headers:{
      'Content-Type':'application/json',
      'Authorization': localStorage.getItem("token")
    },
    body: JSON.stringify({ name, quantity, price }) // ✅ FIXED
  });

  location.reload();
}

// DELETE
async function del(id){
  await fetch('/delete/'+id,{
    method:'DELETE',
    headers:{ 'Authorization': localStorage.getItem("token") }
  });

  location.reload();
}

// EDIT + UPDATE
function edit(id,n,q,p){
  document.getElementById("name").value = n;
  document.getElementById("qty").value = q;
  document.getElementById("price").value = p;

  const btn = document.getElementById("mainBtn");
  btn.innerText = "Update";

  btn.onclick = async function(){
    await fetch('/update/'+id,{
      method:'PUT',
      headers:{
        'Content-Type':'application/json',
        'Authorization': localStorage.getItem("token")
      },
      body: JSON.stringify({
        name: document.getElementById("name").value,
        quantity: document.getElementById("qty").value,
        price: document.getElementById("price").value
      })
    });

    location.reload();
  }
}

// AUTO LOAD
if(window.location.pathname.includes("dashboard")){
  loadDashboard();
}

if(window.location.pathname.includes("manage")){
  loadManage();
}