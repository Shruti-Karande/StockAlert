const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');

const app = express();
const SECRET = "mysecretkey";

app.use(bodyParser.json());
app.use(express.static('public'));

mongoose.connect("mongodb://admin:1234@ac-ogfdnqc-shard-00-00.mvjebye.mongodb.net:27017,ac-ogfdnqc-shard-00-01.mvjebye.mongodb.net:27017,ac-ogfdnqc-shard-00-02.mvjebye.mongodb.net:27017/?ssl=true&replicaSet=atlas-8quj58-shard-0&authSource=admin&appName=Cluster0")
.then(async () => {
  console.log("MongoDB Connected");

  // ✅ Run only AFTER connection
  const u = await User.findOne({ username: "admin" });
  if (!u) {
    await User.create({ username: "admin", password: "1234" });
    console.log("Default user created");
  }
})
.catch(err => console.log("Mongo Error:", err));

// Models
const User = mongoose.model('User', {
  username: String,
  password: String
});

const Product = mongoose.model('Product', {
  name: String,
  quantity: Number,
  price: Number
});

// Default user
User.findOne({username:"admin"}).then(u=>{
  if(!u){
    User.create({username:"admin", password:"1234"});
  }
});

// Middleware
function auth(req,res,next){
  const token = req.headers.authorization;
  if(!token) return res.send("Access Denied");

  try{
    const verified = jwt.verify(token, SECRET);
    req.user = verified;
    next();
  }catch{
    res.send("Invalid Token");
  }
}

// Login
app.post('/login', async (req,res)=>{
  const user = await User.findOne(req.body);
  if(!user) return res.send("fail");

  const token = jwt.sign({username:user.username}, SECRET);
  res.json({token});
});

// Routes
app.get('/products', auth, async (req,res)=>{
  res.json(await Product.find());
});

app.post('/add', auth, async (req,res)=>{
  await Product.create(req.body);
  res.send("added");
});

app.delete('/delete/:id', auth, async (req,res)=>{
  await Product.findByIdAndDelete(req.params.id);
  res.send("deleted");
});

app.put('/update/:id', auth, async (req,res)=>{
  await Product.findByIdAndUpdate(req.params.id, req.body);
  res.send("updated");
});

app.listen(3000, ()=>console.log("Server running on 3000"));